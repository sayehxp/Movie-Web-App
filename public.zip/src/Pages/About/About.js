//____________ABOUT________________
import React from 'react'
//__________________________
const About = () => {


  return (
    <div>About</div>
  )
}

export default About