import React from "react";
export const langContext = React.createContext()
export const LangProvider = langContext.Provider



